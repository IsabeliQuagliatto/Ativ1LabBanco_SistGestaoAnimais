package dao;

import conexao.Conexao;
import conexao.ItensAtividades;
import conexao.Recurso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Isabe
 */
public class ItensAtividadesDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ItensAtividadesDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    //CRUD
    //Create
    public void inserir(ItensAtividades atividades){
        String sql = "INSERT into ItensAtividades(atividade, recurso, descricao, quantidade, unidadeMedida) "
                                      + "values(?, ?, ?, ?, ?);";
        try
        {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, atividades.getAtividade());
            stmt.setString(2, atividades.getRecurso().getNome());
            stmt.setString(3, atividades.getDescricao());
            stmt.setDouble(4, atividades.getQuantidade());
            stmt.setString(5, atividades.getUnidadeMedida());
            
            stmt.execute();
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao inserir item da atividade: " + ex.getMessage());
        }
    }
    
    //Sei la o que to fazendo
    public List<ItensAtividades> listaItensCategoria(){
        String sql = "SELECT i.id, i.atividade, i.recurso, i.descricao, i.quantidade, i.unidadeMedida "
                + "r.id AS idRecurso, r.nome AS nomeRecurso "
                + "FROM ItensAtividades i INNER JOIN Recurso r ON i.recurso = r.id;";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            
            List<ItensAtividades> listaItens = new ArrayList();
            
            while (rs.next())
            {
                conexao.Recurso r = new conexao.Recurso();
                r.setId(rs.getInt("idRecurso"));
                r.setNome(rs.getString("nomeRecurso"));
                
                ItensAtividades i = new ItensAtividades();
                i.setId(rs.getInt("id"));
                i.setAtividade(rs.getString("atividade"));
                i.setRecurso(r);
                i.setDescricao(rs.getString("descricao"));
                i.setQuantidade(rs.getDouble("quantidade"));
                i.setUnidadeMedida(rs.getString("unidadeMedida"));
                
                listaItens.add(i);
            }
            return listaItens;
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao consultar todos os itens: " + ex.getMessage());
            return null;
        }
    }
}
