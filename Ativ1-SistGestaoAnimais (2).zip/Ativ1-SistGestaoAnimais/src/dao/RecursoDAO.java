package dao;

import conexao.Conexao;
import conexao.Recurso;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Isabe
 */
public class RecursoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public RecursoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    //CRUD
    //Create
    public void inserir(Recurso recurso){
        String sql = "INSERT into Recurso(nome, categoria, unidadeMedida, descricao) values(?, ?, ?, ?);";
        try
        {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, recurso.getNome());
            stmt.setString(2, recurso.getCategoria());
            stmt.setString(3, recurso.getUnidadeMedida());
            stmt.setString(4, recurso.getDescricao());
            
            stmt.execute();
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao inserir recurso: " + ex.getMessage());
        }
    }
    
    //Read
    public Recurso getRecurso(int id){
        String sql = "SELECT * FROM Recurso WHERE id = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, 
                    ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Recurso r = new Recurso();
            
            rs.first();
            r.setId(id);
            r.setNome(rs.getString("nome"));
            r.setCategoria(rs.getString("categoria"));
            r.setUnidadeMedida(rs.getString("unidadeMedida"));
            r.setDescricao(rs.getString("descricao"));
            
            return r;
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao consultar recurso: " + ex.getMessage());
            return null;
        }
    }
    
    //Update
    public void atualizar(Recurso recurso){
        try
        {
            String sql = "UPDATE Recurso set nome = ?, categoria = ?, unidadeMedida = ?, descricao = ? WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, recurso.getNome());
            stmt.setString(2, recurso.getCategoria());
            stmt.setString(3, recurso.getUnidadeMedida());
            stmt.setString(4, recurso.getDescricao());
            stmt.setInt(5, recurso.getId());
            
            //executa
            stmt.execute();
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao atualizar recurso: " + ex.getMessage());
        }
    }
    
    //Delete
    public void deletar(int id){
        String sql = "DELETE from Recurso WHERE id = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.execute();
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao deletar animal: " + ex.getMessage());
        }
    }
    
    //Lista Geral
    public List<Recurso> lista()
    {
        String sql = "SELECT * FROM Recurso;";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            
            List<Recurso> listaRecursos = new ArrayList();
            
            while (rs.next())
            {
                Recurso r = new Recurso();
                r.setId(rs.getInt("id"));
                r.setNome(rs.getString("nome"));
                r.setCategoria(rs.getString("categoria"));
                r.setUnidadeMedida(rs.getString("unidadeMedida"));
                r.setDescricao(rs.getString("descricao"));
                listaRecursos.add(r);
            }
            return listaRecursos;
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao consultar todos os recursos: " + ex.getMessage());
            return null;
        }
    }
}
