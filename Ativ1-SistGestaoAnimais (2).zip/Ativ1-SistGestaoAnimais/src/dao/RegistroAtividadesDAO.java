 package dao;

import conexao.Conexao;
import conexao.RegistroAtividades;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Isabe
 */
public class RegistroAtividadesDAO {
    private Conexao conexao;
    private Connection conn;
    
    public RegistroAtividadesDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    //CRUD
    //Create
    public void inserir(RegistroAtividades registro){
        String sql = "INSERT into Atividades(animal, tipoAtividade, data, horario, descricao, itens, status) "
                                      + "values(?, ?, ?, ?, ?, ?, ?);";
        try
        {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, registro.getAnimal().getId());
            stmt.setString(2, registro.getTipoAtividade());
            stmt.setString(3, registro.getData());
            stmt.setString(4, registro.getHorario());
            stmt.setString(5, registro.getDescricao());
           // stmt.setInt(6, registro.addItens());
            stmt.setString(7, registro.getStatus());
            
            stmt.execute();
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao inserir registro da atividade: " + ex.getMessage());
        }
    }
    
    //Read
    /*
    public RegistroAtividades getRegistroAtividades(int id){
        String sql = "SELECT * FROM Registro WHERE id = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, 
                    ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Animal a = new Animal();
            
            rs.first();
            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setEspecie(rs.getString("especie"));
            a.setSexo(rs.getString("sexo"));
            a.setPeso(rs.getDouble("peso"));
            a.setIdadeAnos(rs.getInt("idadeAnos"));
            a.setIdadeMeses(rs.getInt("idadeMeses"));
            a.setDataNascimento(rs.getString("dataNascimento"));
            a.setDataEntrada(rs.getString("dataEntrada"));
            a.setTipoOrigem(rs.getString("tipoOrigem"));
            a.setCondicaoChegada(rs.getString("condicaoChegada"));
            a.setFoto(rs.getString("foto"));
            
            return a;
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao consultar animal: " + ex.getMessage());
            return null;
        }
    }
    
    //Update
    public void editar(Animal animal){
        try
        {
            String sql = "UPDATE Animal set nome = ?, especie = ?, sexo= ?, peso = ?, idadeAnos = ?, idadeMeses = ?"
                   + "dataNascimento = ?, dataEntrada = ?, tipoOrigem = ?, condicaoEntrada = ?, foto = ? WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getEspecie());
            stmt.setString(3, animal.getSexo());
            stmt.setDouble(4, animal.getPeso());
            stmt.setInt(5, animal.getIdadeAnos());
            stmt.setInt(6, animal.getIdadeMeses());
            stmt.setString(7, animal.getDataNascimento());
            stmt.setString(8, animal.getDataEntrada());
            stmt.setString(9, animal.getTipoOrigem());
            stmt.setString(10, animal.getCondicaoChegada());
            stmt.setString(11, animal.getFoto());
            stmt.setInt(12, animal.getId());
            
            //executa
            stmt.execute();
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao atualizar animal: " + ex.getMessage());
        }
    }
    
    //Delete
    public void delete(int id){
        String sql = "DELETE from Animal WHERE id = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.execute();
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao deletar animal: " + ex.getMessage());
        }
    }
    
    //Lista
    public List<RegistroAtividades> getRegistro()
    {
        String sql = "SELECT * FROM RegistroAtividades;";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            
            List<RegistroAtividades> listaRegistros = new ArrayList();
            
            while (rs.next())
            {
                RegistroAtividades a = new RegistroAtividades();
                a.setId(rs.getInt("id"));
                a.setAnimal(rs.getString.getNome("animal"));
                a.setEspecie(rs.getString("especie"));
                a.setSexo(rs.getString("sexo"));
                a.setPeso(rs.getDouble("peso"));
                a.setIdadeAnos(rs.getInt("idadeAnos"));
                a.setIdadeMeses(rs.getInt("idadeMeses"));
                a.setDataNascimento(rs.getString("dataNascimento"));
                a.setDataEntrada(rs.getString("dataEntrada"));
                a.setTipoOrigem(rs.getString("tipoOrigem"));
                a.setCondicaoChegada(rs.getString("condicaoChegada"));
                a.setFoto(rs.getString("foto"));
                listaAnimais.add(a);
            }
            return listaAnimais;
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao consultar todos os animais: " + ex.getMessage());
            return null;
        }
    }*/
    
    /*public List<> getRegistro()
    {
        String sql = "SELECT * FROM RegistroAtividades;";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            
            List<RegistroAtividades> listaRegistros = new ArrayList();
            
            while (rs.next())
            {
                RegistroAtividades a = new RegistroAtividades();
                a.setId(rs.getInt("id"));
                a.setAnimal(rs.getString.getNome("animal"));
                a.setEspecie(rs.getString("especie"));
                a.setSexo(rs.getString("sexo"));
                a.setPeso(rs.getDouble("peso"));
                a.setIdadeAnos(rs.getInt("idadeAnos"));
                a.setIdadeMeses(rs.getInt("idadeMeses"));
                a.setDataNascimento(rs.getString("dataNascimento"));
                a.setDataEntrada(rs.getString("dataEntrada"));
                a.setTipoOrigem(rs.getString("tipoOrigem"));
                a.setCondicaoChegada(rs.getString("condicaoChegada"));
                a.setFoto(rs.getString("foto"));
                listaAnimais.add(a);
            }
            return listaAnimais;
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao consultar todos os animais: " + ex.getMessage());
            return null;
        }
    }*/
    
}
