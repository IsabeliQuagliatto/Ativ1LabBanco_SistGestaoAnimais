/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.Conexao;
import conexao.Animal;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Isabeli
 */

public class AnimalDAO {
    private Conexao conexao;
    private Connection conn;
    
    public AnimalDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    //CRUD
    //Create
    public void inserir(Animal animal){
        String sql = "INSERT into Animal(nome, especie, sexo, peso, idadeAnos, idadeMeses, dataNascimento, "
                                      + "dataEntrada, tipoOrigem, condicaoChegada, foto)"
                                      + "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try
        {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getEspecie());
            stmt.setString(3, animal.getSexo());
            stmt.setDouble(4, animal.getPeso());
            stmt.setInt(5, animal.getIdadeAnos());
            stmt.setInt(6, animal.getIdadeMeses());
            stmt.setString(7, animal.getDataNascimento());
            stmt.setString(8, animal.getDataEntrada());
            stmt.setString(9, animal.getTipoOrigem());
            stmt.setString(10, animal.getCondicaoChegada());
            stmt.setString(11, animal.getFoto());
            
            stmt.execute();
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao inserir animal: " + ex.getMessage());
        }
    }
    
    //Read
    public Animal getAnimal(int id){
        String sql = "SELECT * FROM Animal WHERE id = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, 
                    ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Animal a = new Animal();
            
            rs.first();
            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setEspecie(rs.getString("especie"));
            a.setSexo(rs.getString("sexo"));
            a.setPeso(rs.getDouble("peso"));
            a.setIdadeAnos(rs.getInt("idadeAnos"));
            a.setIdadeMeses(rs.getInt("idadeMeses"));
            a.setDataNascimento(rs.getString("dataNascimento"));
            a.setDataEntrada(rs.getString("dataEntrada"));
            a.setTipoOrigem(rs.getString("tipoOrigem"));
            a.setCondicaoChegada(rs.getString("condicaoChegada"));
            a.setFoto(rs.getString("foto"));
            
            return a;
        }
        catch (Exception ex)
        {
            System.out.println("Erro ao consultar animal: " + ex.getMessage());
            return null;
        }
    }
    
    //Update
    public void atualizar(Animal animal){
        try
        {
            String sql = "UPDATE Animal set nome = ?, especie = ?, sexo = ?, peso = ?, idadeAnos = ?, idadeMeses = ?, "
                   + "dataNascimento = ?, dataEntrada = ?, tipoOrigem = ?, condicaoChegada = ?, foto = ? WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getEspecie());
            stmt.setString(3, animal.getSexo());
            stmt.setDouble(4, animal.getPeso());
            stmt.setInt(5, animal.getIdadeAnos());
            stmt.setInt(6, animal.getIdadeMeses());
            stmt.setString(7, animal.getDataNascimento());
            stmt.setString(8, animal.getDataEntrada());
            stmt.setString(9, animal.getTipoOrigem());
            stmt.setString(10, animal.getCondicaoChegada());
            stmt.setString(11, animal.getFoto());
            stmt.setInt(12, animal.getId());
            
            //executa
            stmt.execute();
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao atualizar animal: " + ex.getMessage());
        }
    }
    
    //Delete
    public void deletar(int id){
        String sql = "DELETE from Animal WHERE id = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.execute();
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao deletar animal: " + ex.getMessage());
        }
    }
    
    //Lista
    public List<Animal> lista()
    {
        String sql = "SELECT * FROM Animal;";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            
            List<Animal> listaAnimais = new ArrayList();
            
            while (rs.next())
            {
                Animal a = new Animal();
                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setEspecie(rs.getString("especie"));
                a.setSexo(rs.getString("sexo"));
                a.setPeso(rs.getDouble("peso"));
                a.setIdadeAnos(rs.getInt("idadeAnos"));
                a.setIdadeMeses(rs.getInt("idadeMeses"));
                a.setDataNascimento(rs.getString("dataNascimento"));
                a.setDataEntrada(rs.getString("dataEntrada"));
                a.setTipoOrigem(rs.getString("tipoOrigem"));
                a.setCondicaoChegada(rs.getString("condicaoChegada"));
                a.setFoto(rs.getString("foto"));
                listaAnimais.add(a);
            }
            return listaAnimais;
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao consultar todos os animais: " + ex.getMessage());
            return null;
        }
    }
    
    //Pesquisar por espécie
    public List<Animal> getAnimalEspecie(String atributo){
        
        String sql = "SELECT * FROM Animal WHERE especie LIKE = ?";
        
        try
        {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            //Pesquisa
            stmt.setString(1, "%" + atributo + "%");
            
            List<Animal> listaAnimais = new ArrayList();
            
            while (rs.next()){
                Animal a = new Animal();
                
                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setEspecie(rs.getString("especie"));
                a.setSexo(rs.getString("sexo"));
                a.setPeso(rs.getDouble("peso"));
                a.setIdadeAnos(rs.getInt("idadeAnos"));
                a.setIdadeMeses(rs.getInt("idadeMeses"));
                a.setDataNascimento(rs.getString("dataNascimento"));
                a.setDataEntrada(rs.getString("dataEntrada"));
                a.setTipoOrigem(rs.getString("tipoOrigem"));
                a.setCondicaoChegada(rs.getString("condicaoChegada"));
                a.setFoto(rs.getString("foto"));
                listaAnimais.add(a);
            }
            return listaAnimais;
        }
        catch (SQLException ex)
        {
            System.out.println("Erro ao consultar todos os animais: " + ex.getMessage());
            return null;
        }
    }
}
