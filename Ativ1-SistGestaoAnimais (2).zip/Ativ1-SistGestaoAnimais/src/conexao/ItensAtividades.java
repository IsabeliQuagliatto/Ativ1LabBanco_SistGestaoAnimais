/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;

/**
 *
 * @author Isabe
 */
public class ItensAtividades {
    private int id;
    private String atividade;
    private Recurso recurso;
    private String descricao;
    private double quantidade;
    private String unidadeMedida;

    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }
    
    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }
    public String getAtividade() {
        return atividade;
    }
    
    public void setRecurso(Recurso recurso) {
        this.recurso = recurso;
    }
    public Recurso getRecurso() {
        return recurso;
    }
    
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }
    public String getDescricao(){
        return descricao;
    }
    
    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }
    public double getQuantidade() {
        return quantidade;
    }
    
    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }
    public String getUnidadeMedida() {
        return unidadeMedida;
    }
}
