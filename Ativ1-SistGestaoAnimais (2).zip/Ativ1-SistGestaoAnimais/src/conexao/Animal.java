package conexao;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Isabeli
 */
public class Animal {
    private int id;
    private String nome;
    private String especie;
    private String sexo;
    private double peso;
    private int idadeAnos;
    private int idadeMeses;
    private String dataNascimento;
    private String dataEntrada;
    private String tipoOrigem;
    private String condicaoChegada;
    private String foto;

    
    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getNome() {
        return nome;
    }
    
    public void setEspecie(String especie) {
        this.especie = especie;
    }
    public String getEspecie() {
        return especie;
    }
  
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    public String getSexo() {
        return sexo;
    }
    
    public void setPeso(double peso) {
        this.peso = peso;
    }
    public double getPeso() {
        return peso;
    }
    
    public void setIdadeAnos(int idadeAnos) {
        this.idadeAnos = idadeAnos;
    }
    public int getIdadeAnos() {
        return idadeAnos;
    }
    
    public void setIdadeMeses(int idadeMeses) {
        this.idadeMeses = idadeMeses;
    }
    public int getIdadeMeses() {
        return idadeMeses;
    }
    
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }public String getDataNascimento() {
        return dataNascimento;
    }
    
    public void setDataEntrada(String dataEntrada) {
        this.dataEntrada = dataEntrada;
    }
    public String getDataEntrada() {
        return dataEntrada;
    }
    
    public void setTipoOrigem(String tipoOrigem) {
        this.tipoOrigem = tipoOrigem;
    }
    public String getTipoOrigem() {
        return tipoOrigem;
    }
    
    public void setCondicaoChegada(String condicaoChegada) {
        this.condicaoChegada = condicaoChegada;
    }
    public String getCondicaoChegada() {
        return condicaoChegada;
    }
    
    public void setFoto(String foto) {
        this.foto = foto;
    }
    public String getFoto() {
        return foto;
    }
    
    //para inserir no comboBox
    public String toString(String nome, String especie){
        return (nome + "—" + especie);
    }
}
