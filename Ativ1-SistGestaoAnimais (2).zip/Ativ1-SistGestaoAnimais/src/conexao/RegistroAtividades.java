/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;

import java.util.ArrayList;

/**
 *
 * @author Isabe
 */
public class RegistroAtividades {
    private int id;
    private Animal animal;
    private String tipoAtividade;
    private String data;
    private String horario;
    private String descricao;
    private ArrayList<ItensAtividades> itens;
    private String status;
    
    public RegistroAtividades(){
        itens = new ArrayList<ItensAtividades>();
    }

    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }
    
    public void setAnimal(Animal animal) {
        this.animal = animal;
    }
    public Animal getAnimal() {
        return animal;
    }
    
    public void setTipoAtividade(String tipoAtividade) {
        this.tipoAtividade = tipoAtividade;
    }
    public String getTipoAtividade() {
        return tipoAtividade;
    }
    
    public void setData(String data) {
        this.data = data;
    }
    public String getData() {
        return data;
    }
    
    public void setHorario(String horario) {
        this.horario = horario;
    }
    public String getHorario() {
        return horario;
    }
    
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getDescricao() {
        return descricao;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    public String getStatus() {
        return status;
    }
    
    //pq preciso disso aqui?
    public ArrayList<ItensAtividades> getItens() {
       return itens;
    }
    
    public void addItens (ItensAtividades i){
        itens.add(i);
    }
}
